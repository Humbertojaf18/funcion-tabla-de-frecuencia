#' Clase S4 para almacenar tablas de frecuencias y medidas descriptivas
#'
#' La clase \code{TablaFrecuencias} almacena una tabla de frecuencias y medidas
#' descriptivas calculadas para una columna numerica de un data frame, incluyendo
#' estadisticas como media, mediana, cuartiles, moda, desviacion estandar, y mas.
#' Tambien puede contener un grafico opcional y valores atipicos detectados.
#'
#' @slot tabla_frecuencias Data frame con la tabla de frecuencias, incluyendo columnas
#'   como Intervalo, Frecuencia_Absoluta, Frecuencia_Acumulada, etc.
#' @slot media Media de los datos (numerico).
#' @slot cuartil1 Primer cuartil (Q1) de los datos (numerico).
#' @slot mediana Mediana de los datos (numerico).
#' @slot cuartil3 Tercer cuartil (Q3) de los datos (numerico).
#' @slot moda_frecuencia Moda no agrupada de los datos (numerico, puede ser NA o vector).
#' @slot moda_agrupada Moda agrupada calculada desde los intervalos (numerico, puede ser NA o vector).
#' @slot minimo Valor minimo de los datos (numerico).
#' @slot maximo Valor maximo de los datos (numerico).
#' @slot rango Rango de los datos (maximo - minimo, numerico).
#' @slot desviacion_estandar Desviacion estandar de los datos (numerico).
#' @slot varianza Varianza de los datos (numerico).
#' @slot coef_variacion Coeficiente de variacion en porcentaje (numerico).
#' @slot valores_faltantes Numero de valores NA en los datos (numerico).
#' @slot valores_atipicos Valores atipicos detectados, si los hay (numerico, puede ser NA).
#' @slot grafico Objeto grafico, tipicamente un objeto ggplot (o NULL si no se genera).
#' @slot decimales Numero de decimales usados para redondear los resultados (numerico).
#' @slot column Nombre de la columna analizada (caracter).
#' @exportClass TablaFrecuencias
setClass(
  "TablaFrecuencias",
  slots = list(
    tabla_frecuencias = "data.frame",
    media = "numeric",
    cuartil1 = "numeric",
    mediana = "numeric",
    cuartil3 = "numeric",
    moda_frecuencia = "numeric",
    moda_agrupada = "numeric",
    minimo = "numeric",
    maximo = "numeric",
    rango = "numeric",
    desviacion_estandar = "numeric",
    varianza = "numeric",
    coef_variacion = "numeric",
    valores_faltantes = "numeric",
    valores_atipicos = "numeric",
    grafico = "ANY",
    decimales = "numeric",
    column = "character"
  ),
  validity = function(object) {
    if (!is.data.frame(object@tabla_frecuencias)) {
      return("El slot 'tabla_frecuencias' debe ser un data.frame.")
    }
    if (!all(c("Intervalo", "Frecuencia_Absoluta", "Frecuencia_Acumulada",
               "Frecuencia_Relativa", "Frecuencia_Relativa_Acumulada",
               "Frecuencia_Porcentual", "Frecuencia_Porcentual_Acumulada") %in%
             names(object@tabla_frecuencias))) {
      return("El slot 'tabla_frecuencias' debe contener todas las columnas requeridas.")
    }
    if (object@decimales < 0 || object@decimales != floor(object@decimales)) {
      return("El slot 'decimales' debe ser un entero no negativo.")
    }
    if (length(object@column) != 1 || !is.character(object@column)) {
      return("El slot 'column' debe ser una cadena de caracteres de longitud 1.")
    }
    return(TRUE)
  }
)

#' Genera una tabla de frecuencias y medidas descriptivas
#'
#' Esta funcion calcula una tabla de frecuencias y estadisticas descriptivas
#' (media, mediana, cuartiles, moda, etc.) para una columna numerica de un
#' data frame. Permite manejar valores atipicos, generar graficos y exportar
#' resultados a CSV o Excel.
#'
#' @param data Data frame que contiene los datos.
#' @param column Nombre de la columna numerica a analizar (caracter).
#' @param k Numero de intervalos para la tabla de frecuencias (entero, opcional).
#'   Si es \code{NULL}, se usa la regla de Sturges.
#' @param decimales Numero de decimales para redondear los resultados (entero, por defecto 4).
#' @param handle_outliers Logico, si \code{TRUE}, elimina valores atipicos usando el metodo IQR.
#' @param plot Logico, si \code{TRUE}, genera un histograma usando \code{ggplot2}.
#' @param export Ruta del archivo para exportar la tabla (caracter, opcional, debe terminar en \code{.csv} o \code{.xlsx}).
#' @param silent Logico, si \code{FALSE}, imprime resultados en la consola y muestra la tabla en una ventana interactiva.
#' @param view_table Lógico, indica si se debe visualizar la tabla de frecuencias (TRUE por defecto).
#' @return Un objeto de clase \code{TablaFrecuencias} que contiene la tabla de frecuencias
#'   y medidas descriptivas.
#' @examples
#' set.seed(123)
#' df <- data.frame(valores = c(1, 2, 2, 3, 3, 3, 4, 4, 5, NA, 10))
#' resultado <- tabla_frecuencias(df, "valores", decimales = 2, silent = TRUE)
#' print(resultado)
#' plot(resultado)
#' @importFrom ggplot2 ggplot aes geom_histogram scale_x_continuous labs theme_minimal element_text
#' @importFrom writexl write_xlsx
#' @importFrom stats median quantile sd var
#' @importFrom utils write.csv View
#' @importFrom methods new show
#' @export
tabla_frecuencias <- function(data, column, k = NULL, decimales = 2, handle_outliers = FALSE,
                              plot = FALSE, export = NULL, silent = FALSE, view_table = FALSE) {

  # Validar que data sea un dataframe
  if (!is.data.frame(data)) {
    stop("El argumento 'data' debe ser un dataframe.")
  }

  # Validar que column sea una cadena y exista en el dataframe
  if (!is.character(column) || !column %in% names(data)) {
    stop("El argumento 'column' debe ser el nombre de una columna valida en el dataframe.")
  }

  # Extraer la columna especificada
  t <- data[[column]]

  # Contar valores NA
  n_na <- sum(is.na(t))
  n <- sum(!is.na(t))
  if (n == 0) {
    stop("No hay datos no nulos en la columna especificada.")
  }

  # Validar que la columna sea numerica
  if (!is.numeric(t)) {
    stop("La columna especificada debe ser numerica.")
  }

  # Manejo de valores atipicos (si handle_outliers = TRUE)
  t_clean <- t
  outliers <- NULL
  if (handle_outliers) {
    t_no_na <- t[!is.na(t)]
    if (length(t_no_na) == 0) {
      stop("No hay datos no nulos en la columna especificada para manejar valores atipicos.")
    }
    q1 <- unname(as.numeric(stats::quantile(t_no_na, 0.25, na.rm = TRUE)))
    q3 <- unname(as.numeric(stats::quantile(t_no_na, 0.75, na.rm = TRUE)))
    iqr <- q3 - q1
    lower_bound <- q1 - 1.5 * iqr
    upper_bound <- q3 + 1.5 * iqr
    outliers <- t_no_na[t_no_na < lower_bound | t_no_na > upper_bound]
    t_clean <- t[t <= upper_bound & t >= lower_bound & !is.na(t)]
    if (length(t_clean) == 0) {
      stop("Despues de eliminar valores atipicos, no quedan datos validos.")
    }
    n <- sum(!is.na(t_clean))
    if (!silent) {
      cat("Valores atipicos detectados y excluidos:", length(outliers), "\n")
    }
  }

  # Filtrar valores no finitos
  t_clean <- t_clean[!is.na(t_clean) & is.finite(t_clean)]
  if (length(t_clean) == 0) {
    stop("No hay datos validos despues de filtrar valores no finitos.")
  }
  if (length(t_clean) < 2) {
    stop("No hay suficientes datos validos para crear una tabla de frecuencias.")
  }

  # Calcular el numero intervalos usando la regla de Sturges si k es NULL
  if (is.null(k)) {
    k <- ceiling(1 + 3.322 * log10(n))
  } else {
    if (!is.numeric(k) || k <= 0 || k != floor(k)) {
      stop("El argumento 'k' debe ser un numero entero positivo.")
    }
  }

  # Calcular el rango de los datos
  rango <- max(t_clean, na.rm = TRUE) - min(t_clean, na.rm = TRUE)

  # Calcular el ancho de los intervalos
  amplitud <- rango / k

  # Crear los puntos de corte (breaks) para los intervalos
  breaks <- seq(min(t_clean, na.rm = TRUE), max(t_clean, na.rm = TRUE), by = amplitud)

  # Ajustar breaks para incluir el maximo si es necesario
  if (max(t_clean, na.rm = TRUE) > max(breaks)) {
    breaks <- c(breaks, max(breaks) + amplitud)
  }

  # Verificar que haya suficientes puntos de corte
  if (length(breaks) <= 1) {
    stop("No se pueden crear intervalos: el rango de los datos es demasiado pequeno.")
  }

  # Crear los intervalos
  intervalos <- cut(t_clean, breaks = breaks, right = TRUE, include.lowest = TRUE)

  # Calcular frecuencias absolutas
  absoluta <- table(intervalos)

  # Calcular frecuencias acumuladas
  acumulada <- cumsum(absoluta)

  # Calcular frecuencias relativas
  relativa <- prop.table(absoluta)

  # Calcular frecuencias relativas acumuladas
  r_acumulada <- cumsum(relativa)

  # Calcular frecuencias porcentuales
  porcentual <- relativa * 100

  # Calcular frecuencias porcentuales acumuladas
  p_acumulada <- cumsum(porcentual)

  # Crear la tabla de frecuencias con redondeo configurable
  tabla_frecuencias <- data.frame(
    Intervalo = names(absoluta),
    Frecuencia_Absoluta = as.vector(absoluta),
    Frecuencia_Acumulada = as.vector(acumulada),
    Frecuencia_Relativa = sprintf(paste0("%.", decimales, "f"), as.vector(relativa)),
    Frecuencia_Relativa_Acumulada = sprintf(paste0("%.", decimales, "f"), as.vector(r_acumulada)),
    Frecuencia_Porcentual = sprintf(paste0("%.", decimales, "f"), as.vector(porcentual)),
    Frecuencia_Porcentual_Acumulada = sprintf(paste0("%.", decimales, "f"), as.vector(p_acumulada))
  )

  # Calcular medidas descriptivas
  m <- mean(t_clean, na.rm = TRUE)
  q1 <- unname(as.numeric(stats::quantile(t_clean, 0.25, na.rm = TRUE)))
  me <- stats::median(t_clean, na.rm = TRUE)
  q3 <- unname(as.numeric(stats::quantile(t_clean, 0.75, na.rm = TRUE)))

  # Moda para datos no agrupados
  obtener_moda <- function(x) {
    ux <- unique(x[!is.na(x)])
    tab <- tabulate(match(x, ux))
    max_freq <- max(tab)
    if (max_freq == 0) return(NA_real_)
    modas <- ux[tab == max_freq]
    if (length(modas) == length(ux)) return(NA_real_)
    return(modas)
  }
  moda <- obtener_moda(t_clean)

  # Moda agrupada
  max_freq <- max(tabla_frecuencias$Frecuencia_Absoluta)
  idx_modales <- which(tabla_frecuencias$Frecuencia_Absoluta == max_freq)
  modas_agrupadas <- numeric(length(idx_modales))
  for (i in seq_along(idx_modales)) {
    idx_modal <- idx_modales[i]
    inter_modal <- tabla_frecuencias$Intervalo[idx_modal]
    inter_limpio <- gsub("\\[|\\]|\\(|\\)", "", inter_modal)
    valores <- as.numeric(unlist(strsplit(inter_limpio, ",")))
    limite_inf_modal <- valores[1]
    fmodal <- tabla_frecuencias$Frecuencia_Absoluta[idx_modal]
    fanterior <- ifelse(idx_modal > 1, tabla_frecuencias$Frecuencia_Absoluta[idx_modal - 1], 0)
    fposterior <- ifelse(idx_modal < nrow(tabla_frecuencias),
                         tabla_frecuencias$Frecuencia_Absoluta[idx_modal + 1], 0)
    denominator <- (fmodal - fanterior) + (fmodal - fposterior)
    if (denominator == 0 || is.na(denominator)) {
      modas_agrupadas[i] <- NA
    } else {
      mo <- limite_inf_modal + ((fmodal - fanterior) / denominator) * amplitud
      modas_agrupadas[i] <- round(mo, decimales)
    }
  }

  # Rango de valores
  rango_valores <- range(t_clean, na.rm = TRUE)
  rango_dif <- diff(rango_valores)

  # Desviacion estandar
  desvest <- stats::sd(t_clean, na.rm = TRUE)

  # Varianza
  varianza <- stats::var(t_clean, na.rm = TRUE)

  # Coeficiente de variacion
  cv <- (desvest / m) * 100

  # Generar grafico con ggplot2 si plot = TRUE
  grafico <- NULL
  if (plot) {
    if (!requireNamespace("ggplot2", quietly = TRUE)) {
      warning("El paquete 'ggplot2' no esta instalado. Instalalo para generar graficos.")
    } else {
      midpoints <- (breaks[-length(breaks)] + breaks[-1]) / 2
      df_plot <- data.frame(values = t_clean)
      grafico <- ggplot2::ggplot(df_plot, ggplot2::aes(x = values)) +
        ggplot2::geom_histogram(breaks = breaks, fill = "lightblue", color = "black") +
        ggplot2::scale_x_continuous(
          breaks = midpoints,
          labels = tabla_frecuencias$Intervalo
        ) +
        ggplot2::labs(title = paste("Histograma de", column), x = column, y = "Frecuencia") +
        ggplot2::theme_minimal() +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
    }
  }

  # Exportar tabla si se especifica un archivo
  if (!is.null(export)) {
    if (!is.character(export)) {
      warning("El argumento 'export' debe ser una cadena con la ruta del archivo.")
    } else {
      if (grepl("\\.csv$", export)) {
        utils::write.csv(tabla_frecuencias, file = export, row.names = FALSE)
        if (!silent) {
          cat("Tabla exportada como CSV en:", export, "\n")
        }
      } else if (grepl("\\.xlsx$", export)) {
        if (!requireNamespace("writexl", quietly = TRUE)) {
          warning("El paquete 'writexl' no esta instalado. Instalalo para exportar a Excel.")
        } else {
          writexl::write_xlsx(tabla_frecuencias, path = export)
          if (!silent) {
            cat("Tabla exportada como Excel en:", export, "\n")
          }
        }
      } else {
        warning("Formato de archivo no soportado. Usa '.csv' o '.xlsx'.")
      }
    }
  }

  # Crear objeto de clase S4
  resultado <- new("TablaFrecuencias",
                   tabla_frecuencias = tabla_frecuencias,
                   media = m,
                   cuartil1 = q1,
                   mediana = me,
                   cuartil3 = q3,
                   moda_frecuencia = if (length(moda) == 0) NA_real_ else moda,
                   moda_agrupada = if (length(modas_agrupadas) == 0) NA_real_ else modas_agrupadas,
                   minimo = min(t_clean, na.rm = TRUE),
                   maximo = max(t_clean, na.rm = TRUE),
                   rango = rango_dif,
                   desviacion_estandar = desvest,
                   varianza = varianza,
                   coef_variacion = cv,
                   valores_faltantes = n_na,
                   valores_atipicos = if (length(outliers) == 0) NA_real_ else outliers,
                   grafico = grafico,
                   decimales = decimales,
                   column = column
  )

  # Imprimir resultados si silent = FALSE
  if (!silent) {
    show(resultado)
  }

  # Visualizacion en entorno interactivo
  if (interactive() && !silent) {
    utils::View(tabla_frecuencias)
  }

  return(invisible(resultado))
}

#' Metodo show para la clase TablaFrecuencias
#'
#' Muestra en consola la tabla de frecuencias y las medidas descriptivas almacenadas
#' en un objeto de clase \code{TablaFrecuencias}, incluyendo valores faltantes,
#' medidas de tendencia central y medidas de variabilidad.
#'
#' @param object Objeto de clase \code{TablaFrecuencias}.
#' @examples
#' set.seed(123)
#' df <- data.frame(valores = c(1, 2, 2, 3, 3, 3, 4, 4, 5, NA, 10))
#' resultado <- tabla_frecuencias(df, "valores", decimales = 2, silent = TRUE)
#' show(resultado)
#' @export
setMethod("show", "TablaFrecuencias", function(object) {
  cat("\nTabla de Frecuencias, Medidas de Tendencia Central y Dispersion para la variable", object@column, "\n")
  if (object@valores_faltantes > 0) {
    cat("Valores faltantes (NA):", object@valores_faltantes, "\n")
  }
  cat("\n")
  print(object@tabla_frecuencias, row.names = FALSE)
  cat("\nMedidas de tendencia central:\n")
  cat("\n")
  cat("Media:", round(object@media, object@decimales), "\n")
  cat("Cuartil 1:", round(object@cuartil1, object@decimales), "\n")
  cat("Mediana:", round(object@mediana, object@decimales), "\n")
  cat("Cuartil 3:", round(object@cuartil3, object@decimales), "\n")
  cat("Moda (frecuencia):",
      if (length(object@moda_frecuencia) > 1) paste(round(object@moda_frecuencia, object@decimales), collapse = ", ")
      else if (is.na(object@moda_frecuencia)) "No definida"
      else round(object@moda_frecuencia, object@decimales), "\n")
  cat("Moda (datos agrupados):",
      if (length(object@moda_agrupada) > 1) paste(round(object@moda_agrupada, object@decimales), collapse = ", ")
      else if (all(is.na(object@moda_agrupada))) "No definida"
      else round(object@moda_agrupada, object@decimales), "\n")
  cat("\nMedidas de variabilidad:\n")
  cat("\n")
  cat("Minimo:", round(object@minimo, object@decimales), "\n")
  cat("Maximo:", round(object@maximo, object@decimales), "\n")
  cat("Rango:", round(object@rango, object@decimales), "\n")
  cat("Desviacion Estandar:", round(object@desviacion_estandar, object@decimales), "\n")
  cat("Varianza:", round(object@varianza, object@decimales), "\n")
  cat("Coeficiente de Variacion (%):", round(object@coef_variacion, object@decimales), "\n")
})

#' Metodo plot para la clase TablaFrecuencias
#'
#' Muestra el histograma almacenado en el slot \code{grafico} de un objeto de clase
#' \code{TablaFrecuencias}, si existe. Si no se genero un grafico, muestra un mensaje
#' indicando que se debe usar \code{plot = TRUE} al crear el objeto.
#'
#' @param x Objeto de clase \code{TablaFrecuencias}.
#' @param y No se usa (incluido por compatibilidad).
#' @param ... Argumentos adicionales (no usados).
#' @examples
#' set.seed(123)
#' df <- data.frame(valores = c(1, 2, 2, 3, 3, 3, 4, 4, 5, NA, 10))
#' resultado <- tabla_frecuencias(df, "valores", plot = TRUE, silent = TRUE)
#' plot(resultado)
#' @export
setMethod("plot", "TablaFrecuencias", function(x, y, ...) {
  if (is.null(x@grafico)) {
    cat("No se genero un grafico. Usa plot = TRUE al crear el objeto.\n")
  } else {
    print(x@grafico)
  }
})
